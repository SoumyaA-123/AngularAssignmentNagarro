import { Component, OnInit } from '@angular/core';
import { User } from '../models/User.interface';

@Component({
  selector: 'app-table-component',
  templateUrl: './table-component.component.html',
  styleUrls: ['./table-component.component.scss']
})
export class TableComponentComponent implements OnInit {
  users:User[]=[
    {
      name:'suman',
      username:'suman123',
      email:'suman@gmail.com'
    },
    {
      name:'shivani',
      username:'shiavni543',
      email:'shivani@gmail.com'
    },
    {
      name:'payal',
      username:'payalsingh222',
      email:'payal@gmail.com'
    },
    {
      name:'chanchal',
      username:'chanchal00',
      email:'chanchal@gmail.com'
    }
  ];
  constructor() { }
handleDelete(userIndex:number){
this.users.splice(userIndex,1);
}
  ngOnInit(): void {
  }

}
